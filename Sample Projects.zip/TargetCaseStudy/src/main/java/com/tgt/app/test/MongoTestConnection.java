package com.tgt.app.test;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoTestConnection {

	public static void main(String[] args)
	{
		MongoTestConnection mongoTestConnect =  new MongoTestConnection();
		mongoTestConnect.test();
	}
	private static void test() {


	    //String url = "mongodb://user:pwd@host:19468/heroku_dbname";
		//  mongodb://<dbuser>:<dbpassword>@ds153835.mlab.com:53835/hadoopintra
	    MongoClientURI uri = new MongoClientURI("mongodb://shyam:pavithra@ds153835.mlab.com:53835/hadoopintra");

	    MongoClient mongoClient = new MongoClient(uri);


	    // get handle to "heroku_dbname" database
	    MongoDatabase database = mongoClient.getDatabase("hadoopintra");


	    // get a handle to the "book" collection
	    MongoCollection<Document> collection = database.getCollection("test1");

	    // make a document and insert it
	    Document doc = new Document("title", "Good Habits")
	                   .append("author", "Akbar");

	    collection.insertOne(doc);

	    // get it (since it's the only one in there since we dropped the rest earlier on)
	    Document myDoc = collection.find().first();
	    System.out.println("output from mlab mongo cluster is -->"+myDoc.toJson());

	    // release resources
	    mongoClient.close();
	}
}
